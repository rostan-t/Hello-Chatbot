exceptions = ["mer", "certes", "mais", "vos", "onques", "nos", "talent", "omnipotent", "jadis",
              'et', 'je', 'certes', 'que', 'mais', 'ne', 'me', 'de', 'ce', 'qui', 'la', 'li', 'le',
              'ma', 'mon', 'si', 'sa', 'son', 'chambre', 'quant', 'ki', 'tut']