PUNJABI_CORPORA = [
    {'name': 'punjabi_text_gurban',
     'origin': 'https://github.com/cltk/punjabi_text_gurban.git',
     'location': 'remote',
     'type': 'text'
    }
]
