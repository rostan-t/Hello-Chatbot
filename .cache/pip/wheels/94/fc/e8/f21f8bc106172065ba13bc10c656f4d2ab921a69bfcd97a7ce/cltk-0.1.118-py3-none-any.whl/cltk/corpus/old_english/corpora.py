OLD_ENGLISH_CORPORA = [
    {'name': 'old_english_text_sacred_texts',
     'origin': 'https://github.com/cltk/old_english_text_sacred_texts.git',
     'location': 'remote',
     'type': 'html'
    },
    {'origin': 'https://github.com/cltk/old_english_models_cltk.git',
     'name': 'old_english_models_cltk',
     'location': 'remote',
	'type': 'model'
	}
]
