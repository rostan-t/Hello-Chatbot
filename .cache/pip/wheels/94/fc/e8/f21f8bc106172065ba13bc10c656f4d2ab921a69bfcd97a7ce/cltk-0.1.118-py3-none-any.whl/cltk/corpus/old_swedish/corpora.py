OLD_SWEDISH_CORPORA = [
    {"encoding": "utf-8",
     "name": "old_swedish_texts",
     "location": "remote",
     "origin": "https://github.com/cltk/old_swedish_texts.git",
     "type": "text"
     },
]
