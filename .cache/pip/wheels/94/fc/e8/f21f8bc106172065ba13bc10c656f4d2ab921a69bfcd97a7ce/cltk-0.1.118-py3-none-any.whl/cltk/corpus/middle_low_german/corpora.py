MIDDLE_LOW_GERMAN_CORPORA = [{
                         'name': 'middle_low_german_models_cltk',
                         'origin': 'https://github.com/cltk/middle_low_german_models_cltk.git',
                         'location': 'remote',
                         'type': 'model'
}]
