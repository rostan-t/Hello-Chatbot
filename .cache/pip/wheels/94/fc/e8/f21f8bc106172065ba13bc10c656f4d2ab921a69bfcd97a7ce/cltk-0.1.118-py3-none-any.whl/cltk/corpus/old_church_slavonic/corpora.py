"""Old Church Slavonic corpora available for download: """
OCS_CORPORA = [
			   {'name': 'old_church_slavonic_ccmh',
			    'origin': 'https://github.com/cltk/old_church_slavonic_ccmh.git',
			    'location': 'remote',
			    'type': 'text'}
]
