BENGALI_CORPORA = [
    {'encoding': 'utf-8',
	 'name': 'bengali_text_wikisource',
     'origin': 'https://github.com/cltk/bengali_text_wikisource.git',
     'location': 'remote',
     'type': 'text'
    }
]
