greek_sub_patterns = [
    ('(ων)(ος|ι|να)$', r'ων'),
]
