TELUGU_CORPORA = [
        {'name':'telugu_text_wikisource',
         'origin': 'https://github.com/cltk/telugu_text_wikisource.git',
         'location':'remote',
        'type':'text'},
]
